/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <radar.h>

#include <stdlib.h>
#include <strings.h>



#include <diskio.h>
#include <ff.h>

CY_ISR(ButtonInt)
{
    
}

int main()
{
    CyGlobalIntEnable;
    
    int buff[512];
    //int i;
    char file_number;
    char Ready=0;
    
    Counter_Start();
    Counter_SetInterruptMode(Counter_STATUS_ZERO_INT_EN_MASK);
    isr_ButtonInt_StartEx(ButtonInt);
    
    

    file_number=sd_MakeFile();  //makes a formated wave file "Data_#.wave"
    
    ADC_Start();
    
    for(;;)
    {
        while(Ready==0);
        capture_Wave(buff); //Takes 512 data points and stores in buff
        sd_WriteFile(buff,file_number); //writes buffered data to wave file with number #
    }
    //for(;;);
}


