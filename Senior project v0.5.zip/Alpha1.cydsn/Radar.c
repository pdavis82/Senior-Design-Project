/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include <project.h>
#include <stdlib.h>
#include <strings.h>
#include <diskio.h>
#include <ff.h>

void FatFsError(FRESULT result);


void capture_Wave(int *data)
{
    int i=0;
    ADC_StartConvert();
       for(i=0;i<512;i++)
        {
            ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
            data[i]=ADC_GetResult16(0u);
        }
    ADC_StopConvert();
}


char sd_MakeFile()
{
    FATFS fatFs;
    FIL file;
    uint8 resultF;
    //FATFS *fatFsPtr;
    //FRESULT fr;
    //uint32_t size;
    int i;
    
    char name[10]="Data_0.wav";
    name[5]=0x01;

    char init[44]={0x52,0x49,0x46,0x46,0xD4,0xAD,0x01,
                 0x00,0x57,0x41,0x56,0x45,0x66,0x6D,
                 0x74,0x20,0x10,0x00,0x00,0x00,0x01,
                 0x00,0x01,0x00,0x20,0xA1,0x07,0x00,
                 0x40,0x42,0x0F,0x00,0x02,0x00,0x10,
                 0x00,0x64,0x61,0x74,0x61,0xB0,0xAD,
                 0x01,0x00};
    
    
    
    
    
    resultF = f_mount(&fatFs, "", 1);
    
    if(resultF != RES_OK)
    {
        FatFsError(resultF);
        return 0x00;
    }
    
    
    for(i=1;i>256;i++)
    {
        resultF = f_open(&file, name, FA_CREATE_NEW);
        
        if(resultF==0)
        {
            break;
        }
        name[5]++;
        FatFsError(resultF);
        
    }
    
    f_puts (init,&file);
    
    f_close(&file);
    
    
    UART_UartPutString("DONE");
    
    return name[5];
    
}

void sd_WriteFile(int *data,char number)
{
    FATFS fatFs;
    FIL file;
    uint8 resultF;
    char buff[1024];
    int i;
    
    char name[10]="Data_0.wav";
    name[5]=number;
    
     resultF = f_mount(&fatFs, "", 1);
    
    if(resultF != RES_OK)
    {
        FatFsError(resultF);
        return;
    }
    
    for(i=0;i<512;i++)
    {
        buff[i]=(unsigned char)(data[i]>>8);
        buff[i+1]=(unsigned char)(data[i]&0xFF);
    }
    
    resultF = f_open(&file, name, FA_WRITE);
    
    if(resultF != RES_OK)
    {
        FatFsError(resultF);
        return;
    }
    
    
    f_puts (buff,&file);

    f_close(&file);


}


void FatFsError(FRESULT result)
{
    switch (result)
    {
        case FR_DISK_ERR:
            UART_UartPutString("\n    error: (FR_DISK_ERR) low level error.\n"); break;
            
        case FR_INT_ERR:
            UART_UartPutString("\n    error: (FR_INT_ERR)\n"); break; 
            
        case FR_NOT_READY:
            UART_UartPutString("\n    error: (FR_NOT_READY) sdcard not ready.\n"); break;
            
        case FR_NO_FILE:
            UART_UartPutString("\n    error: (FR_NO_FILE) invalid file.\n"); break;
            
        case FR_NO_PATH:
            UART_UartPutString("\n    error: (FR_NO_PATH) invalid path.\n"); break;
            
        case FR_INVALID_NAME:
            UART_UartPutString("\n    error: (FR_INVALID_NAME) invalid name.\n"); break;
            
        case FR_DENIED:
            UART_UartPutString("\n    error: (FR_DENIED) operation denied.\n"); break;
            
        case FR_EXIST:
            UART_UartPutString("\n    error: (FR_EXIST) it exists yet...\n"); break;
            
        case FR_INVALID_OBJECT:
            UART_UartPutString("\n    error: (FR_INVALID_OBJECT)\n"); break;
            
        case FR_WRITE_PROTECTED:
            UART_UartPutString("\n    error: (FR_WRITE_PROTECTED)\n"); break;
            
        case FR_INVALID_DRIVE:
            UART_UartPutString("\n    error: (FR_INVALID_DRIVE)\n"); break;
            
        case FR_NOT_ENABLED:
            UART_UartPutString("\n    error: (FR_NOT_ENABLED) sdcard unmounted.\n"); break;
            
        case FR_NO_FILESYSTEM:
            UART_UartPutString("\n    error: (FR_NO_FILESYSTEM) no valid FAT volume.\n"); break;  
            
        case FR_MKFS_ABORTED:
            UART_UartPutString("\n    error: (FR_MKFS_ABORTED)\n"); break;
            
        case FR_TIMEOUT:
            UART_UartPutString("\n    error: (FR_TIMEOUT)\n"); break;
            
        case FR_LOCKED:
            UART_UartPutString("\n    error: (FR_LOCKED)\n"); break;
            
        case FR_NOT_ENOUGH_CORE:
            UART_UartPutString("\n    error: (FR_NOT_ENOUGH_CORE)\n"); break;     
            
        case FR_TOO_MANY_OPEN_FILES:
            UART_UartPutString("\n    error: (FR_TOO_MANY_OPEN_FILES)\n"); break;
            
        case FR_INVALID_PARAMETER:
            UART_UartPutString("\n    error: (FR_INVALID_PARAMETER)\n"); break; 
            
        default: {}; break;
    }
}
