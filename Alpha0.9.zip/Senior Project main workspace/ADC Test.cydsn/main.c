/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

int main()
{
    CyGlobalIntEnable;
    ADC_Start();

    int buff[512];
    int i;
    int dataReady=0;

    
    ADC_StartConvert();
       for(i=0;i<512;i++)
        {
            ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
            buff[i]=ADC_GetResult16(0u);
        }
    for(;;);
     
}
