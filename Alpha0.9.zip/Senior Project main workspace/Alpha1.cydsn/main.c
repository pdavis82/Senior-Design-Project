
#include <project.h>
#include <radar.h>
#include <stdlib.h>
#include <strings.h>
#include <diskio.h>
#include <ff.h>


char Ready=0;
char file[10]="Data_0.wav";


CY_ISR(ButtonInt)
{
    Ready=1;
    UART_UartPutString("\nInterrupt\n");
    Counter_WriteCounter(1000);
    Counter_ClearFIFO();
}

int main()
{
    CyGlobalIntEnable;
    
    int buff[512];
    char file_number;

    ADC_Start();
    UART_Start();
    SPI_Start();
    UART_UartPutString("Test\n");
    
    Counter_Start();
    Counter_WriteCounter(1000);
    Counter_SetInterruptMode(Counter_STATUS_ZERO_INT_EN_MASK);
    isr_ButtonInt_StartEx(ButtonInt);


    file_number=sd_MakeFile(file);  //makes a formated wave file "Data_#.wav"
    
    if(file_number==0x00)
    {
        UART_UartPutString("Something went wrong\n");
        for(;;);
    }
    
    //ADC_Start();
    
    for(;;)
    {
        UART_UartPutString("\nWaiting\n");
        
        while(Ready!=1);
        
        capture_Wave(buff); //Takes 512 data points and stores in buff
        sd_WriteFile(buff,file); //writes buffered data to wave file with number #
        Ready=0;
        UART_UartPutString("\nDone\n");
    }
    
}


