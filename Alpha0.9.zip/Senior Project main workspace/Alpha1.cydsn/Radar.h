/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */
#ifndef radar_H
#define radar_H
    

void capture_Wave(int *data);
void sd_WriteFile(int *data,char *name);
char sd_MakeFile(char *name);

//const int S_SIZE=8000;
    
    
#endif